// cordova.js - this file is a placeholder. The shell app will intercept any request for cordova.js and
// serve the device specific file.
